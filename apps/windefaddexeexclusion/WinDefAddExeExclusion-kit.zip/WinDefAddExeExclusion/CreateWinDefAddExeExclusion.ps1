# CreateWinDefAddExeExclusion.ps1
# Builds the portable single-file EXE using PyInstaller.
# Now uses relative paths based on the script location so it works from any folder.

$scriptDir = $PSScriptRoot
if (-not $scriptDir) {
    $scriptDir = (Get-Location).Path
}

$pythonScript = Join-Path $scriptDir "WinDefAddExeExclusion.py"
$exeOutputDir = Join-Path $scriptDir "dist"
$exeOutput = Join-Path $exeOutputDir "WinDefAddExeExclusion.exe"
$manifestFile = Join-Path $scriptDir "WinDefAddExeExclusion.exe.manifest"

Write-Output "=== WinDefAddExeExclusion Build Script ==="
Write-Output "Working from: $scriptDir"

# Verify required files exist
if (-not (Test-Path $pythonScript)) {
    Write-Output "ERROR: Python script not found at $pythonScript"
    exit 1
}
if (-not (Test-Path $manifestFile)) {
    Write-Output "ERROR: Manifest file not found at $manifestFile"
    exit 1
}

# Ensure dist folder exists
if (-not (Test-Path $exeOutputDir)) {
    New-Item -ItemType Directory -Path $exeOutputDir | Out-Null
}

# Check / install PyInstaller
try {
    $pyinstallerCheck = & python -m pip show pyinstaller 2>$null
    if (-not $pyinstallerCheck) {
        Write-Output "PyInstaller not found. Installing..."
        & python -m pip install pyinstaller --quiet
    } else {
        Write-Output "PyInstaller is available."
    }
} catch {
    Write-Output "ERROR: Python or pip not found in PATH. Please install Python 3."
    exit 1
}

# Build the portable EXE
Write-Output "`nBuilding portable .exe (this may take a minute)..."
$pyinstallerArgs = @(
    "--onefile",
    "--noconsole",
    "--name", "WinDefAddExeExclusion",
    "--manifest", "`"$manifestFile`"",
    "--distpath", "`"$exeOutputDir`"",
    "`"$pythonScript`""
)

Push-Location $scriptDir
& python -m PyInstaller @pyinstallerArgs
$buildExit = $LASTEXITCODE
Pop-Location

if ($buildExit -ne 0 -or -not (Test-Path $exeOutput)) {
    Write-Output "ERROR: PyInstaller build failed. Check output above and the build/ folder for logs."
    exit 1
}

Write-Output "SUCCESS: Portable EXE created at $exeOutput"

# Optional: Try to verify the embedded manifest requires admin (needs Resource Hacker)
Write-Output "`nChecking embedded manifest (optional)..."
$rhPath = "C:\Program Files (x86)\Resource Hacker\ResourceHacker.exe"
$tempManifest = Join-Path $env:TEMP "wd_manifest_check.xml"

if (Test-Path $rhPath) {
    try {
        & $rhPath -open $exeOutput -save $tempManifest -action extract -mask RT_MANIFEST,1 -quiet 2>$null
        if (Test-Path $tempManifest) {
            $content = Get-Content $tempManifest -Raw
            if ($content -match "requireAdministrator") {
                Write-Output "Good: Manifest inside the EXE requests requireAdministrator."
            } else {
                Write-Output "Warning: requireAdministrator not detected in the embedded manifest."
            }
            Remove-Item $tempManifest -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Write-Output "Warning: Could not verify manifest with Resource Hacker."
    }
} else {
    Write-Output "Info: Resource Hacker not found at default location. Skipping manifest verification."
    Write-Output "       (You can install it from https://www.angusj.com/resourcehacker/ if you want this check.)"
}

# Clean PyInstaller temp artifacts
Write-Output "`nCleaning build artifacts..."
Remove-Item -Path (Join-Path $scriptDir "build") -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path (Join-Path $scriptDir "WinDefAddExeExclusion.spec") -Force -ErrorAction SilentlyContinue

Write-Output "`nBuild complete. You can now run the new EXE from dist\ as Administrator."
Write-Output "Size: $((Get-Item $exeOutput).Length / 1MB) MB (typical for PyInstaller onefile + Tkinter)"