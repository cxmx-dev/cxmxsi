# WinDefAddExeExclusion

**A portable, retro Windows 98-style GUI for adding or removing individual `.exe` files from the Windows Defender exclusion list.**

It was built while turning lots of locally compiled code into standalone `.exe` files (PyInstaller, `cargo build --release`, and similar). Windows Defender kept flagging the freshly built executables, so this small Tkinter GUI was created as a quick, visual way to manage exclusions for your own trusted builds.

---

## ⚠️ Read this first

- **This tool lowers your Windows Defender protection.** Every exclusion you add tells Defender to stop scanning that executable — even if that file is later replaced or infected. Only exclude files you built or fully trust, and remove the exclusion when you no longer need it.
- **Never exclude a whole folder or a drive.** A folder exclusion means *everything* dropped into it (now or later) escapes scanning — a common malware trick. This tool works on one `.exe` at a time by design. Do not add folder exclusions by hand either.
- **It requires Administrator.** Changing Defender preferences needs elevation, so the program requests a UAC prompt on launch.
- **The `.exe` is an unsigned PyInstaller build, so antivirus (including Defender and SmartScreen) may flag or quarantine it.** This is an expected false positive for unsigned one-file PyInstaller executables, not proof it is malicious. The full source is included so you can read it and rebuild the binary yourself (see "Building from source").

---

## Features

- Browse for an `.exe`, or pick from a live list of current Defender exclusions
- Add any single `.exe` to exclusions with one click (shows the file's SHA-256 and asks you to confirm first)
- Remove exclusions directly from the list (multi-select supported), with verification that they are actually gone
- Double-click any list item to load it into the path field
- Verify / refresh the live list from Defender
- Warns you when the chosen file is under Downloads or Temp, or when the path is a folder rather than an `.exe`
- Logs every add and remove with a timestamp to `%LOCALAPPDATA%\WinDefAddExeExclusion\exclusions.log`
- Single-file portable executable, no install required
- Manifest forces Administrator elevation
- Deliberate Windows 98 gray aesthetic

---

## Requirements

- Windows 10 or 11
- Must be run as Administrator (a UAC prompt will appear)

The built `.exe` is standalone. The other files are only needed to read or rebuild the tool.

---

## How to use

1. Right-click `WinDefAddExeExclusion.exe` -> **Run as administrator**.
2. You will see a live list of everything currently excluded by Defender.
3. Either click **Browse...** and pick an `.exe`, or double-click a list item to load it into the path field.
4. Click **Add Exclusion** or **Remove Selected** (multi-select is supported in the list).
5. Click **Verify / Refresh** (or **Refresh List**) any time to re-sync the list from Defender.

The status label at the bottom reports the result of each action.

---

## Building from source

A PowerShell build script is included:

```powershell
.\CreateWinDefAddExeExclusion.ps1
```

Requirements:
- Python 3 installed and on PATH
- PyInstaller (`pip install pyinstaller`)
- (Optional) Resource Hacker, only if you want the script to verify the embedded manifest

The script:
- Resolves all paths relative to its own location, so it runs from any folder
- Bundles `WinDefAddExeExclusion.py` + the manifest into a single `.exe` with `--onefile --noconsole`
- Cleans up the `build` folder and the `.spec` file afterward

Output: `dist\WinDefAddExeExclusion.exe`

Because the binary is unsigned, rebuilding it from this source is the recommended way to get a copy you have verified yourself. After editing any source file, re-run the build script to produce an updated `.exe`; the old binary will not contain your changes.

---

## Limitations & known issues

- The ~12 MB size is normal for a PyInstaller `--onefile` build that bundles Tkinter and the Python runtime.
- Paths containing single quotes can still be problematic in the PowerShell backend (rare).
- Works with individual `.exe` files only — no wildcards, and by design no folder or drive exclusions.
- Removing an exclusion is permanent: Defender resumes scanning that executable.

---

## Troubleshooting

| Problem | Likely cause / fix |
|---------|--------------------|
| No window appears or nothing happens | You didn't run it as Administrator |
| Add/Remove buttons do nothing or show permission errors | Not elevated — right-click the EXE and choose "Run as administrator" |
| "Error adding exclusion" | Not elevated, or Defender is blocked by another policy or Tamper Protection |
| Exclusion added but the file still gets flagged | Some detections need a full scan or reboot. Prefer reporting the false positive to Microsoft or signing your build — do **not** exclude the whole folder |
| List doesn't update after Add/Remove | Click **Refresh List** or **Verify / Refresh** |

---

## Better than an exclusion

An exclusion means Defender never scans that file again, even if it is later replaced or infected. Prefer these instead:

1. **Report the false positive to Microsoft.** Submit the file at https://www.microsoft.com/wdsi/filesubmission (choose "Incorrectly detected"). Once Microsoft clears it, it's cleared for everyone.
2. **Sign your builds.** A code-signing certificate, or Azure Trusted Signing, plus `signtool sign /fd SHA256 /tr <timestamp-url> /td SHA256 your.exe` builds reputation that SmartScreen and Defender trust over time.
3. If you must exclude something, exclude one exact `.exe`, never a folder or drive, and remove the exclusion when you're done.

---

## Notes

- This tool only modifies the Windows Defender exclusion list. It does not disable Defender or make other system changes.
- Originally created 2025-10-21 (UTC) to deal with Defender false positives on freshly built executables. Later updates added the live exclusion list, remove support, relative build paths, better admin detection, and safer PowerShell handling.
- The source is intentionally small and hackable.

Built with Python + Tkinter and PyInstaller.
