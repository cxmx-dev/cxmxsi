import tkinter as tk
from tkinter import filedialog
import subprocess
import os
import ctypes
import hashlib
import datetime
from tkinter import messagebox

LOG_PATH = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "WinDefAddExeExclusion", "exclusions.log")

def log_action(action, path, result):
    try:
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(f"{stamp}\t{action}\t{result}\t{path}\n")
    except Exception:
        pass

def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()

RISKY_DIRS = [os.environ.get("TEMP", ""), os.environ.get("TMP", ""),
              os.path.join(os.path.expanduser("~"), "Downloads")]

def risk_warning(path):
    norm = os.path.normcase(os.path.abspath(path))
    if os.path.isdir(path):
        return "This is a whole FOLDER. Everything inside it would skip Defender scans."
    for d in RISKY_DIRS:
        if d and norm.startswith(os.path.normcase(os.path.abspath(d)) + os.sep):
            return f"This file is under {d}. Downloads and Temp are where malware usually lands."
    if not norm.endswith(".exe"):
        return "This is not an .exe file."
    return None

# --- Better admin check using ctypes (more reliable than net session) ---
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

# --- Run PowerShell command robustly and capture output ---
def run_powershell(cmd):
    """Returns (success: bool, stdout_lines: list[str], stderr: str)"""
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
            capture_output=True,
            text=True,
            check=False
        )
        stdout_lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        stderr = result.stderr.strip()
        return (result.returncode == 0), stdout_lines, stderr
    except Exception as e:
        return False, [], str(e)

# --- Escape a path for safe use inside single quotes in PowerShell ---
def ps_escape(path):
    # PowerShell single-quoted strings escape ' by doubling it
    return path.replace("'", "''")

# --- Get current exclusion paths from Defender ---
def get_current_exclusions():
    cmd = "Get-MpPreference | Select-Object -ExpandProperty ExclusionPath"
    success, lines, _ = run_powershell(cmd)
    if not success:
        return []
    return lines

# --- Add a file to exclusions ---
def add_exclusion():
    file_path = text_entry.get().strip()
    if not file_path or not os.path.exists(file_path):
        status_label.configure(text="Error: Select a valid .EXE file.")
        return
    if not is_admin():
        status_label.configure(text="Error: Run this program as Administrator.")
        return

    try:
        digest = sha256_of(file_path)
    except Exception as e:
        status_label.configure(text=f"Error: could not read file ({e}).")
        return
    warn = risk_warning(file_path)
    prompt = f"Exclude this file from Defender?\n\n{file_path}\n\nSHA-256:\n{digest}"
    if warn:
        prompt = f"WARNING: {warn}\n\n" + prompt
    if not messagebox.askyesno("Confirm exclusion", prompt, icon="warning" if warn else "question"):
        status_label.configure(text="Cancelled.")
        return

    escaped = ps_escape(file_path)
    cmd = f"Add-MpPreference -ExclusionPath '{escaped}'"
    success, _, err = run_powershell(cmd)
    log_action("ADD", f"{file_path} sha256={digest}", "ok" if success else f"fail: {err[:200]}")

    if success:
        exclusions = get_current_exclusions()
        if file_path in exclusions:
            status_label.configure(text=f"Success: {file_path} excluded from Defender scans.")
        else:
            status_label.configure(text=f"Warning: Command succeeded but {os.path.basename(file_path)} not confirmed in list.")
        refresh_exclusions_list()
    else:
        msg = f"Error adding exclusion. {err[:120] if err else 'Check permissions or Defender policy.'}"
        status_label.configure(text=msg)

# --- Verify whether the current entry is excluded (also refreshes list) ---
def verify_exclusion():
    refresh_exclusions_list()
    file_path = text_entry.get().strip()
    if not file_path:
        status_label.configure(text="Status: Refreshed current exclusions from Defender.")
        return

    exclusions = get_current_exclusions()
    if file_path in exclusions:
        status_label.configure(text=f"Verified: {file_path} is excluded.")
    else:
        status_label.configure(text=f"Not excluded: {file_path}.")

# --- Remove the item(s) selected in the exclusions listbox ---
def remove_selected():
    selection = exclusions_listbox.curselection()
    if not selection:
        status_label.configure(text="Error: Select one or more exclusions in the list below to remove.")
        return
    if not is_admin():
        status_label.configure(text="Error: Run this program as Administrator.")
        return

    paths = [exclusions_listbox.get(i) for i in selection]
    errors = []
    for path in paths:
        cmd = f"Remove-MpPreference -ExclusionPath '{ps_escape(path)}' -ErrorAction Stop"
        success, _, err = run_powershell(cmd)
        if not success:
            errors.append(f"{os.path.basename(path)}: {err[:150] or 'unknown error'}")
            log_action("REMOVE", path, f"fail: {err[:200]}")

    still_there = set(get_current_exclusions())
    removed = [p for p in paths if p not in still_there]
    for p in removed:
        log_action("REMOVE", p, "ok (verified gone)")
    for p in paths:
        if p in still_there and not any(e.startswith(os.path.basename(p)) for e in errors):
            errors.append(f"{os.path.basename(p)}: command ran but it is still in the list")
            log_action("REMOVE", p, "fail: still listed")

    refresh_exclusions_list()
    if errors:
        status_label.configure(text=f"Removed {len(removed)} of {len(paths)}. Errors: " + " | ".join(errors))
    else:
        status_label.configure(text=f"Removed {len(removed)} exclusion(s), verified gone.")

# --- Populate / refresh the listbox with current Defender exclusions ---
def refresh_exclusions_list():
    exclusions_listbox.delete(0, tk.END)
    exclusions = get_current_exclusions()
    for ex in exclusions:
        exclusions_listbox.insert(tk.END, ex)

# --- Browse for an exe ---
def browse_file():
    file_path = filedialog.askopenfilename(
        filetypes=[("Executable Files", "*.exe")],
        title="Select an .EXE File"
    )
    if file_path:
        text_entry.configure(state="normal")
        text_entry.delete(0, tk.END)
        text_entry.insert(0, file_path)
        text_entry.configure(state="readonly")

# --- Double-click a list item to load it into the entry field ---
def on_list_double_click(event):
    selection = exclusions_listbox.curselection()
    if selection:
        path = exclusions_listbox.get(selection[0])
        text_entry.configure(state="normal")
        text_entry.delete(0, tk.END)
        text_entry.insert(0, path)
        text_entry.configure(state="readonly")
        status_label.configure(text="Loaded from list. Use Add or Remove buttons above.")

# --- GUI setup (kept retro Windows 98 aesthetic) ---
root = tk.Tk()
root.title("WinDefAddExeExclusion - Add / Remove .EXE from Defender")
root.geometry("560x420")
root.resizable(False, False)
root.configure(bg="#C0C0C0")

font = ("Microsoft Sans Serif", 8)

# Instruction label
label = tk.Label(
    root,
    text="Browse for a new .EXE or double-click an item below to load it. Then Add or Remove from Windows Defender exclusions.",
    bg="#C0C0C0", font=font, wraplength=530, justify="left"
)
label.place(x=15, y=10)

# Path entry
text_entry = tk.Entry(root, width=48, font=font, bg="white", fg="black", state="readonly")
text_entry.place(x=15, y=48)

# Browse button
browse_button = tk.Button(root, text="Browse...", font=font, bg="#C0C0C0", fg="black",
                          command=browse_file, relief="raised")
browse_button.place(x=415, y=44, width=80, height=24)

# Main action buttons
add_button = tk.Button(root, text="Add Exclusion", font=font, bg="#C0C0C0", fg="black",
                       command=add_exclusion, relief="raised")
add_button.place(x=15, y=82, width=105, height=24)

verify_button = tk.Button(root, text="Verify / Refresh", font=font, bg="#C0C0C0", fg="black",
                          command=verify_exclusion, relief="raised")
verify_button.place(x=130, y=82, width=105, height=24)

remove_button = tk.Button(root, text="Remove Selected", font=font, bg="#C0C0C0", fg="black",
                          command=remove_selected, relief="raised")
remove_button.place(x=245, y=82, width=115, height=24)

# Current exclusions list section
list_label = tk.Label(
    root,
    text="Current Defender Exclusions (double-click to load into field above):",
    bg="#C0C0C0", font=font
)
list_label.place(x=15, y=115)

# Listbox with scrollbar (retro friendly)
exclusions_listbox = tk.Listbox(
    root, width=68, height=12, font=font,
    bg="white", fg="black", selectmode=tk.EXTENDED, relief="sunken"
)
exclusions_listbox.place(x=15, y=138)
exclusions_listbox.bind("<Double-Button-1>", on_list_double_click)

scrollbar = tk.Scrollbar(root, orient="vertical", command=exclusions_listbox.yview)
scrollbar.place(x=530, y=138, height=192)
exclusions_listbox.config(yscrollcommand=scrollbar.set)

# Refresh button under the list
refresh_button = tk.Button(root, text="Refresh List", font=font, bg="#C0C0C0", fg="black",
                           command=refresh_exclusions_list, relief="raised")
refresh_button.place(x=15, y=340, width=90, height=22)

# Status label
status_label = tk.Label(
    root,
    text="Status: Ready. You must run this program as Administrator to Add or Remove exclusions.",
    bg="#C0C0C0", font=font, wraplength=530, justify="left"
)
status_label.place(x=15, y=375)

# Startup: warn if not admin, then load current exclusions
if not is_admin():
    status_label.configure(text="Status: WARNING - Not running as Administrator. Add/Remove buttons will not work.")

def open_log():
    if os.path.exists(LOG_PATH):
        os.startfile(LOG_PATH)
    else:
        status_label.configure(text="No log yet.")

log_button = tk.Button(root, text="Open Log", font=font, bg="#C0C0C0", fg="black",
                       command=open_log, relief="raised")
log_button.place(x=115, y=340, width=80, height=22)

root.after(120, refresh_exclusions_list)

root.mainloop()
